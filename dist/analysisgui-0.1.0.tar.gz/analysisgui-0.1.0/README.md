Some bullshit here

